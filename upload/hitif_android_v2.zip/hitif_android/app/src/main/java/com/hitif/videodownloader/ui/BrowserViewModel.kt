package com.hitif.videodownloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.hitif.videodownloader.db.AppDatabase
import com.hitif.videodownloader.db.DownloadRecord
import com.hitif.videodownloader.model.MediaItem
import com.hitif.videodownloader.network.MediaDetector
import com.hitif.videodownloader.network.SmartNaming
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.launch

class BrowserViewModel(app: Application) : AndroidViewModel(app) {

    // ── Browser state ────────────────────────────────────────────────────────
    val mediaItems   = MutableLiveData<List<MediaItem>>(emptyList())
    val pageTitle    = MutableLiveData<String>("")
    val pageUrl      = MutableLiveData<String>("")
    val isLoading    = MutableLiveData<Boolean>(false)
    val canGoBack    = MutableLiveData<Boolean>(false)
    val canGoForward = MutableLiveData<Boolean>(false)

    // ── Season candidates (updated whenever mediaItems changes) ──────────────
    val seasonGroups = MutableLiveData<Map<String, List<SmartNaming.EpisodeCandidate>>>(emptyMap())

    // ── Download history from Room ───────────────────────────────────────────
    private val db: AppDatabase by lazy { AppDatabase.getInstance(app) }
    val downloadHistory: LiveData<List<DownloadRecord>> = db.downloadDao().observeAll()

    private val _seenUrls = mutableSetOf<String>()

    val detector = MediaDetector { item ->
        val key = item.url.substringBefore('?')
        synchronized(_seenUrls) {
            if (_seenUrls.add(key)) {
                val current = mediaItems.value.orEmpty().toMutableList()
                current.add(0, item)
                mediaItems.postValue(current)
                // Recompute season groups
                seasonGroups.postValue(SmartNaming.detectSeasonCandidates(current))
            }
        }
    }

    fun clearMedia() {
        _seenUrls.clear()
        detector.reset()
        mediaItems.value = emptyList()
        seasonGroups.value = emptyMap()
    }

    fun removeItem(item: MediaItem) {
        val list = mediaItems.value.orEmpty().toMutableList()
        list.remove(item)
        mediaItems.value = list
        seasonGroups.value = SmartNaming.detectSeasonCandidates(list)
    }

    fun mediaCount(): Int = mediaItems.value?.size ?: 0
    fun hasSeasons(): Boolean = seasonGroups.value?.isNotEmpty() == true

    // ── History operations ───────────────────────────────────────────────────

    fun deleteHistoryRecord(record: DownloadRecord) {
        viewModelScope.launch {
            db.downloadDao().delete(record)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            db.downloadDao().deleteAll()
        }
    }

    fun clearFailedHistory() {
        viewModelScope.launch {
            db.downloadDao().deleteFailedRecords()
        }
    }
}
