package com.hitif.videodownloader.download

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.hitif.videodownloader.db.AppDatabase
import com.hitif.videodownloader.db.DownloadRecord
import com.hitif.videodownloader.model.MediaItem
import com.hitif.videodownloader.model.MediaType
import com.hitif.videodownloader.network.SmartNaming
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object DownloadHelper {

    private val scope = CoroutineScope(Dispatchers.IO)

    fun enqueue(context: Context, item: MediaItem): Long {
        val naming = SmartNaming.build(item)
        return enqueueWithName(context, item, naming.filename, naming)
    }

    fun enqueueBatch(context: Context, items: List<MediaItem>): List<Pair<MediaItem, Long>> {
        return items.map { item -> item to enqueue(context, item) }
    }

    private fun enqueueWithName(
        context: Context,
        item: MediaItem,
        filename: String,
        naming: SmartNaming.NameResult
    ): Long {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        val subDir = when (item.mediaType) {
            MediaType.AUDIO -> "HITIF/Audio"
            MediaType.HLS, MediaType.DASH -> "HITIF/Stream"
            else -> "HITIF/Video"
        }

        val seriesSub = naming.seriesName
            ?.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            ?.take(60)
        val fullSubPath = when {
            seriesSub != null && naming.season != null ->
                "$subDir/$seriesSub/Season_${naming.season.toString().padStart(2,'0')}/$filename"
            seriesSub != null -> "$subDir/$seriesSub/$filename"
            else -> "$subDir/$filename"
        }

        val request = DownloadManager.Request(Uri.parse(item.url)).apply {
            setTitle(filename)
            setDescription("Video Download by HITIF")
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fullSubPath)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            allowScanningByMediaScanner()
            if (item.pageUrl.isNotBlank()) addRequestHeader("Referer", item.pageUrl)
            addRequestHeader("User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
        }

        val dmId = dm.enqueue(request)

        scope.launch {
            AppDatabase.getInstance(context).downloadDao().insert(
                DownloadRecord(
                    downloadManagerId = dmId,
                    url               = item.url,
                    filename          = filename,
                    pageTitle         = item.pageTitle,
                    pageUrl           = item.pageUrl,
                    mimeType          = item.mimeType,
                    mediaType         = item.mediaType.name,
                    sizeBytes         = item.sizeBytes,
                    seriesName        = naming.seriesName,
                    season            = naming.season,
                    episode           = naming.episode,
                    state             = "QUEUED",
                    startedAt         = System.currentTimeMillis()
                )
            )
        }
        return dmId
    }

    fun queryProgress(context: Context, downloadId: Long): DownloadProgress {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val c  = dm.query(DownloadManager.Query().setFilterById(downloadId))
        return if (c != null && c.moveToFirst()) {
            val status   = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val received = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total    = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            c.close()
            DownloadProgress(status, received, total)
        } else {
            c?.close()
            DownloadProgress(DownloadManager.STATUS_FAILED, 0, 0)
        }
    }

    fun syncCompletedState(context: Context, dmId: Long, success: Boolean) {
        scope.launch {
            AppDatabase.getInstance(context).downloadDao().updateState(
                dmId  = dmId,
                state = if (success) "COMPLETED" else "FAILED",
                ts    = System.currentTimeMillis()
            )
        }
    }
}

data class DownloadProgress(
    val status: Int,
    val bytesDownloaded: Long,
    val totalBytes: Long
) {
    val percent: Int    get() = if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt() else -1
    val isRunning: Boolean  get() = status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING
    val isComplete: Boolean get() = status == DownloadManager.STATUS_SUCCESSFUL
    val isFailed: Boolean   get() = status == DownloadManager.STATUS_FAILED
}
