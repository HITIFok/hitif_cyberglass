package com.hitif.videodownloader.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.hitif.videodownloader.R
import com.hitif.videodownloader.databinding.ItemHistoryBinding
import com.hitif.videodownloader.db.DownloadRecord
import com.hitif.videodownloader.model.DownloadState
import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter(
    private val onDelete: (DownloadRecord) -> Unit,
    private val onRetry:  (DownloadRecord) -> Unit,
    private val onShare:  (DownloadRecord) -> Unit
) : ListAdapter<HistoryItem, RecyclerView.ViewHolder>(HistoryDiff) {

    companion object {
        const val TYPE_HEADER  = 0
        const val TYPE_RECORD  = 1
        private val DATE_FMT   = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    }

    inner class HeaderVH(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)
    inner class RecordVH(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun getItemViewType(position: Int) =
        if (getItem(position) is HistoryItem.Header) TYPE_HEADER else TYPE_RECORD

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val b = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return if (viewType == TYPE_HEADER) HeaderVH(b) else RecordVH(b)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is HistoryItem.Header -> bindHeader(holder as HeaderVH, item)
            is HistoryItem.Record -> bindRecord(holder as RecordVH, item.record)
        }
    }

    private fun bindHeader(vh: HeaderVH, h: HistoryItem.Header) = with(vh.binding) {
        // Re-use item layout: show header in title field, hide others
        tvFilename.text = h.label
        tvFilename.setTextColor(ContextCompat.getColor(root.context, R.color.accent_cyan))
        tvDate.text     = ""
        tvSize.text     = ""
        tvState.text    = ""
        tvSeries.text   = ""
        btnDelete.visibility = android.view.View.GONE
        btnRetry.visibility  = android.view.View.GONE
        btnShare.visibility  = android.view.View.GONE
        root.alpha = 1f
        root.setBackgroundResource(R.drawable.bg_history_header)
    }

    private fun bindRecord(vh: RecordVH, r: DownloadRecord) = with(vh.binding) {
        tvFilename.text = r.filename
        tvFilename.setTextColor(
            ContextCompat.getColor(root.context, R.color.text_primary)
        )
        tvDate.text  = DATE_FMT.format(Date(r.startedAt))
        tvSize.text  = r.sizeLabel
        tvSeries.text = r.seriesLabel ?: ""
        tvSeries.visibility = if (r.seriesLabel != null)
            android.view.View.VISIBLE else android.view.View.GONE

        // State badge
        val (stateText, stateColor) = when (r.stateEnum) {
            DownloadState.COMPLETED  -> "✓ COMPLÉTÉ"  to R.color.status_success
            DownloadState.FAILED     -> "✗ ÉCHEC"     to R.color.status_error
            DownloadState.DOWNLOADING -> "⬇ EN COURS" to R.color.accent_cyan
            DownloadState.QUEUED     -> "⏳ EN FILE"  to R.color.accent_violet
            else                     -> "— INACTIF"   to R.color.text_dim
        }
        tvState.text = stateText
        tvState.setTextColor(ContextCompat.getColor(root.context, stateColor))

        root.alpha = if (r.stateEnum == DownloadState.FAILED) 0.6f else 1f
        root.setBackgroundResource(R.drawable.bg_card_item)

        btnDelete.visibility = android.view.View.VISIBLE
        btnRetry.visibility  = if (r.stateEnum == DownloadState.FAILED)
            android.view.View.VISIBLE else android.view.View.GONE
        btnShare.visibility  = android.view.View.VISIBLE

        btnDelete.setOnClickListener { onDelete(r) }
        btnRetry.setOnClickListener  { onRetry(r) }
        btnShare.setOnClickListener  { onShare(r) }
    }
}

// Sealed wrapper so we can show date-group headers
sealed class HistoryItem {
    data class Header(val label: String) : HistoryItem()
    data class Record(val record: DownloadRecord) : HistoryItem()
}

object HistoryDiff : DiffUtil.ItemCallback<HistoryItem>() {
    override fun areItemsTheSame(a: HistoryItem, b: HistoryItem) = when {
        a is HistoryItem.Header && b is HistoryItem.Header -> a.label == b.label
        a is HistoryItem.Record && b is HistoryItem.Record -> a.record.id == b.record.id
        else -> false
    }
    override fun areContentsTheSame(a: HistoryItem, b: HistoryItem) = a == b
}

/** Groups a flat list of DownloadRecord into HistoryItems with date headers */
fun List<DownloadRecord>.toHistoryItems(): List<HistoryItem> {
    if (isEmpty()) return emptyList()
    val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    val result = mutableListOf<HistoryItem>()
    var lastDate = ""
    for (r in this) {
        val date = fmt.format(Date(r.startedAt))
        if (date != lastDate) {
            result += HistoryItem.Header(date)
            lastDate = date
        }
        result += HistoryItem.Record(r)
    }
    return result
}
